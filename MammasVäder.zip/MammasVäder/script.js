/// Josefine Eriksson © 2025 KONTAKT josefineeriksson@live.se

const API_KEY = "ebec561f27ce9600ae91bb091421c7e0";
const CURRENT_WEATHER_API_URL =
  "https://api.openweathermap.org/data/2.5/weather";
const FORECAST_API_URL = "https://api.openweathermap.org/data/2.5/forecast";
const API_ICON_URL = "https://openweathermap.org/img/wn/";
//Sök
const searchInput = document.querySelector(".search-input");
const searchBtn = document.querySelector(".search-btn");
const weatherDisplay = document.querySelector(".weather-display");
const errorMessage = document.querySelector(".error-message");
const forecastDisplay = document.querySelector(".forecast-display");
// Nuvarande väder
const cityNameEl = document.querySelector(".city-name");
const weatherIconEl = document.querySelector(".weather-icon");
const temperatureEl = document.querySelector(".temperature");
const feelsLikeEl = document.querySelector(".feels-like");
const descriptionEl = document.querySelector(".description");
const humidityEl = document.querySelector(".humidity");
const windSpeedEl = document.querySelector(".wind-speed");
const weatherTipEl = document.querySelector(".weather-tip");
//3 timmar fram
const forecastIcon3h = document.querySelector(".forecast-icon-3h");
const forecastTemp3h = document.querySelector(".forecast-temp-3h");
const forecastFeelsLike3h = document.querySelector(".forecast-feels-like-3h");
const forecastDesc3h = document.querySelector(".forecast-desc-3h");
const forecastTip3h = document.querySelector(".forecast-tip-3h");
//6 timmar fram
const forecastIcon6h = document.querySelector(".forecast-icon-6h");
const forecastTemp6h = document.querySelector(".forecast-temp-6h");
const forecastFeelsLike6h = document.querySelector(".forecast-feels-like-6h");
const forecastDesc6h = document.querySelector(".forecast-desc-6h");
const forecastTip6h = document.querySelector(".forecast-tip-6h");
//9 Timmar fram
const forecastIcon9h = document.querySelector(".forecast-icon-9h");
const forecastTemp9h = document.querySelector(".forecast-temp-9h");
const forecastFeelsLike9h = document.querySelector(".forecast-feels-like-9h");
const forecastDesc9h = document.querySelector(".forecast-desc-9h");
const forecastTip9h = document.querySelector(".forecast-tip-9h");
//12 timmar fram
const forecastIcon12h = document.querySelector(".forecast-icon-12h");
const forecastTemp12h = document.querySelector(".forecast-temp-12h");
const forecastFeelsLike12h = document.querySelector(".forecast-feels-like-12h");
const forecastDesc12h = document.querySelector(".forecast-desc-12h");
const forecastTip12h = document.querySelector(".forecast-tip-12h");
//Error
function hideMessages() {
  weatherDisplay.classList.add("hidden");
  errorMessage.classList.add("hidden");
  forecastDisplay.classList.add("hidden");
  weatherTipEl.textContent = "";
}

function showError(message = "Kunde inte hämta väderdata. Försök igen.") {
  hideMessages();
  errorMessage.textContent = message;
  errorMessage.classList.remove("hidden");
}
// Om det är storm
function getWeatherTip(weatherId, temperature, windSpeed) {
  if (windSpeed >= 24) {
    return "Mamma säger: STORM! Stanna helst inne!";
  }

  // SNÖ
  if (weatherId >= 600 && weatherId <= 602) {
    return "Mamma säger: Snö på gång! Klä dig varmt, mössa och vantar!";
  }
  if (weatherId >= 611 && weatherId <= 613) {
    return "Mamma säger: Snöblandat regn! Fodrade regnkläder, eller regnkläder och varma kläder under.";
  }

  // ÅSKA
  if (weatherId >= 200 && weatherId <= 201) {
    return "Mamma säger: Regnkläder och Stövlar på! OBS! INGET PARAPLY och BADA INTE - Du kan bli träffad av blixten!";
  }
  if (weatherId === 202) {
    return "Mamma säger: Du blir nog blöt hur du än gör! Regnkläder och Stövlar på! OBS! INGET PARAPLY och BADA INTE - Du kan bli träffad av blixten!";
  }
  if (weatherId === 210) {
    return "Mamma säger: Regnkläderna behövs inte det ska bara åska utan regn, men ta med en regnjacka i fall att. OBS! INGET PARAPLY och BADA INTE - Du kan bli träffad av blixten!";
  }
  if (weatherId >= 211 && weatherId <= 232) {
    return "Mamma säger: Åska och kanske regn. Se upp för blixten och ta regnkläder! OBS! INGET PARAPLY och BADA INTE - Du kan bli träffad av blixten!";
  }

  // REGN
  if (weatherId >= 300 && weatherId <= 321) {
    return "Mamma säger: Lätt duggregn, ta med ett paraply eller en lätt regnjacka.";
  }
  if (weatherId === 500) {
    return "Mamma säger: Lätt regn, ta med paraply eller regnkläder.";
  }
  if (weatherId === 501) {
    return "Mamma säger: Måttligt regn. Ta med ett paraply eller regnkläder. Ta på dig gummistövlar!";
  }
  if (weatherId >= 502 && weatherId <= 504) {
    return "Mamma säger: Kraftigt regn! Regnkläder och stövlar är ett måste. Det blir blött!";
  }
  if (weatherId >= 520 && weatherId <= 531) {
    return "Mamma säger: Duschregn! Du kommer bli blöt hur du än klär dig, men ta på dig regnkläder och gummistövlar.";
  }

  // DIMMA
  if (weatherId >= 701 && weatherId <= 781) {
    return "Mamma säger: Dimma eller dis, kör försiktigt och var uppmärksam på sikten.";
  }

  // SOL & MOLN
  console.log("hej");
  console.log(weatherId);
  console.log(temperature);
  if (weatherId === 800) {
    // Sol OBS! Räknar Decimaltal så det måste stå exempel > 7 <=12
    if (temperature >= 5 && temperature <= 8) {
      return "Mamma säger: Ta på dig en fodrad jacka.";
    } else if (temperature > 7 && temperature <= 12) {
      return "Mamma säger: Vår/Höst jackan på! Eller ta en kofta eller luvtröja.";
    } else if (temperature > 12 && temperature <= 15) {
      return "Mamma säger: Ta på en jacka, kofta eller en hoodie.";
    } else if (temperature > 15 && temperature <= 19) {
      return "Mamma säger: Kan vara bra att ha med en kofta eller en hoodie, även om du inte behöver ha den på hela tiden.";
    } else if (temperature > 19 && temperature <= 24) {
      return "Mamma säger: Blir ganska varmt idag, ta på en keps eller solhatt.";
    } else if (temperature > 24 && temperature <= 33) {
      return "Mamma säger: OJ OJ!!! Nu blir det jättevarmt! Ta på dig solhatt eller keps! Smörj med solkräm! GLÖM INTE TA MED VATTEN! Du kommer att bli törstig.";
    }
  } else if (weatherId >= 801 && weatherId <= 804) {
    // Molnigt
    if (temperature < 5) {
      return "Mamma säger: Molnigt och kallt. Klä dig varmt!";
    } else if (temperature > 4 && temperature <= 10) {
      return "Mamma säger: Molnigt och lite kyligt, en jacka behövs.";
    } else if (temperature > 10 && temperature <= 15) {
      return "Mamma säger: Molnigt men milt, men en tjocktröja räcker nog.";
    } else if (temperature > 15 && temperature <= 20) {
      return "Mamma säger: Molnigt men ganska varmt. En tjocktröja eller sommarjacka kan vara bra om det blåser.";
    } else if (temperature > 20) {
      return "Mamma säger: Molnigt men varmt. Korta ärmar går bra.";
    }
  }

  // FALLBACK FÖR ALLT ANNAT
  return "Mamma kan inte rekommendera något just nu.";
}

// REALFEEL, Luftfuktighet och Vind
function showCurrentWeather(data) {
  cityNameEl.textContent = data.name;
  weatherIconEl.src = `${API_ICON_URL}${data.weather[0].icon}@2x.png`;
  weatherIconEl.alt = data.weather[0].description;
  temperatureEl.textContent = `${Math.round(data.main.temp)}°C`;
  feelsLikeEl.textContent = `Känns som: ${Math.round(data.main.feels_like)}°C`;
  descriptionEl.textContent =
    data.weather[0].description.charAt(0).toUpperCase() +
    data.weather[0].description.slice(1);
  humidityEl.textContent = `Luftfuktighet: ${data.main.humidity}%`;
  windSpeedEl.textContent = `Vindhastighet: ${data.wind.speed} m/s`;

  weatherTipEl.textContent = getWeatherTip(
    data.weather[0].id,
    data.main.temp,
    data.wind.speed
  );
}

function showForecast(forecastData) {
  const currentTime = Math.floor(Date.now() / 1000);

  let forecast3h = null;
  let forecast6h = null;
  let forecast9h = null;
  let forecast12h = null;

  for (const item of forecastData.list) {
    const timeDiffSeconds = item.dt - currentTime;
    const timeDiffHours = timeDiffSeconds / 3600;
    // logik för 9 och 12 timmar
    if (timeDiffHours >= 2.5 && timeDiffHours < 5.5 && !forecast3h) {
      forecast3h = item;
    } else if (timeDiffHours >= 5.5 && timeDiffHours < 8.5 && !forecast6h) {
      forecast6h = item;
    } else if (timeDiffHours >= 8.5 && timeDiffHours < 11.5 && !forecast9h) {
      forecast9h = item;
    } else if (timeDiffHours >= 11.5 && timeDiffHours < 14.5 && !forecast12h) {
      forecast12h = item;
    }

    if (forecast3h && forecast6h && forecast9h && forecast12h) break;
  }
  //uppdatera enskilda prognoselement
  function updateForecastElement(
    forecastItem,
    iconEl,
    tempEl,
    feelsLikeEl,
    descEl,
    tipEl
  ) {
    if (forecastItem) {
      iconEl.src = `${API_ICON_URL}${forecastItem.weather[0].icon}@2x.png`;
      iconEl.alt = forecastItem.weather[0].description;
      tempEl.textContent = `${Math.round(forecastItem.main.temp)}°C`;
      feelsLikeEl.textContent = `Känns som: ${Math.round(
        forecastItem.main.feels_like
      )}°C`;
      descEl.textContent =
        forecastItem.weather[0].description.charAt(0).toUpperCase() +
        forecastItem.weather[0].description.slice(1);
      tipEl.textContent = getWeatherTip(
        forecastItem.weather[0].id,
        forecastItem.main.temp,
        forecastItem.wind.speed
      );
    } else {
      iconEl.src = "";
      iconEl.alt = "";
      tempEl.textContent = "N/A";
      feelsLikeEl.textContent = "Känns som: N/A";
      descEl.textContent = "N/A";
      tipEl.textContent = "Ingen prognos tillgänglig.";
    }
  }
  // Anrop för 6, 9, 12 timmar
  updateForecastElement(
    forecast3h,
    forecastIcon3h,
    forecastTemp3h,
    forecastFeelsLike3h,
    forecastDesc3h,
    forecastTip3h
  );
  updateForecastElement(
    forecast6h,
    forecastIcon6h,
    forecastTemp6h,
    forecastFeelsLike6h,
    forecastDesc6h,
    forecastTip6h
  );
  updateForecastElement(
    forecast9h,
    forecastIcon9h,
    forecastTemp9h,
    forecastFeelsLike9h,
    forecastDesc9h,
    forecastTip9h
  );
  updateForecastElement(
    forecast12h,
    forecastIcon12h,
    forecastTemp12h,
    forecastFeelsLike12h,
    forecastDesc12h,
    forecastTip12h
  );

  forecastDisplay.classList.remove("hidden");
}

async function fetchWeatherData(city) {
  if (!city) {
    showError("Vänligen ange en stad.");
    return;
  }

  hideMessages();

  // hämta aktuell väderdata
  try {
    const currentUrl = `${CURRENT_WEATHER_API_URL}?q=${city}&appid=${API_KEY}&units=metric&lang=sv`;
    const currentWeatherResponse = await fetch(currentUrl);

    if (!currentWeatherResponse.ok) {
      // Försök läsa felmeddelandet från API:et
      const errorData = await currentWeatherResponse.json();
      let errorMessageText = "Kunde inte hämta aktuell väderdata.";
      if (errorData && errorData.message) {
        errorMessageText = `Fel: ${
          errorData.message.charAt(0).toUpperCase() + errorData.message.slice(1)
        }. Kontrollera stavningen.`;
      } else if (currentWeatherResponse.status === 404) {
        errorMessageText = "Staden hittades inte. Kontrollera stavningen.";
      }
      throw new Error(errorMessageText);
    }

    const currentData = await currentWeatherResponse.json();
    showCurrentWeather(currentData);
    weatherDisplay.classList.remove("hidden");
    // Hämta prognosdata baserat på lat/lon från aktuell data
    const lat = currentData.coord.lat;
    const lon = currentData.coord.lon;
    const forecastUrl = `${FORECAST_API_URL}?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric&lang=sv`;
    const forecastResponse = await fetch(forecastUrl);

    if (!forecastResponse.ok) {
      const errorData = await forecastResponse.json();
      let errorMessageText = "Kunde inte hämta prognosdata.";
      if (errorData && errorData.message) {
        errorMessageText = `Fel vid prognos: ${
          errorData.message.charAt(0).toUpperCase() + errorData.message.slice(1)
        }.`;
      }
      throw new Error(errorMessageText);
    }

    const forecastData = await forecastResponse.json();
    showForecast(forecastData);
  } catch (error) {
    console.error("Kunde inte hämta väderdata:", error);
    showError(error.message); // Använd det mer specifika felmeddelandet
  }
}

searchBtn.addEventListener("click", () => {
  const city = searchInput.value.trim();
  fetchWeatherData(city);
});

searchInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    const city = searchInput.value.trim();
    fetchWeatherData(city);
  }
});

// Nollställer när man laddar om
hideMessages();
